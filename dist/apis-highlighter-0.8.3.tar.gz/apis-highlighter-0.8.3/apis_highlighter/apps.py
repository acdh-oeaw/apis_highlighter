from django.apps import AppConfig


class ApisHighlighterConfig(AppConfig):
    name = 'apis_highlighter'
