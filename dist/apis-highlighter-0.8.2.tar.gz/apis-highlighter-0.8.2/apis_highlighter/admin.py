from django.contrib import admin

from .models import *

admin.site.register(AnnotationProject)
admin.site.register(Annotation)
admin.site.register(Project)
admin.site.register(TextHigh)
admin.site.register(VocabularyAPI)
admin.site.register(MenuEntry)
