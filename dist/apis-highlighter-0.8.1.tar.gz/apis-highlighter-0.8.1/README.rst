Readme
======

This is the highlighter package for the APIS framework. It allows to highlighter and
annotate texts.
