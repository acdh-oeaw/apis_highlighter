Readme
======

This is the core package of the APIS framework. It contains the basic models (entities, relations etc)